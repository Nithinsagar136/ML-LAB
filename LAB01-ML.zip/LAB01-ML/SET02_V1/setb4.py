def matrix():
    
    row = int(input("Enter the number of rows for the matrix: "))
    col = int(input("Enter the number of columns for the matrix: "))

    mat = []
    for i in range(row):
         r = []
         for j in range(col):
             component = float(input(f"Enter component at position ({i+1}, {j+1}): "))
             r.append(component)
         mat.append(r)
    return mat

def transpose(mat):

    transpose_matrix = [[mat[j][i] for j in range(len(mat))] for i in range(len(mat[0]))]
    return transpose_matrix

def display(mat, message="Matrix"):
    print(f"\n{message}:")
    for r in mat:
        print(r)

def main():
    print("Enter the matrix A")
    input_matrix = matrix()

    transpose_matrix = transpose(input_matrix)
    display(transpose_matrix, "Transpose of a Matrix A")

if __name__ == "__main__":
    main()
