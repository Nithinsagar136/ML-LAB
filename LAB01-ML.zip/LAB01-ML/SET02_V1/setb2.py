def matrix():
    
    row = int(input("Enter the number of rows for the matrix: "))
    col = int(input("Enter the number of columns for the matrix: "))

    mat = []
    for i in range(row):
         r = []
         for j in range(col):
             component = float(input(f"Enter component at position ({i+1}, {j+1}): "))
             r.append(component)
         mat.append(r)
    return mat

def multiply(mat_A,mat_B):
    row_A, col_A = len(mat_A), len(mat_A[0])
    row_B, col_B = len(mat_B), len(mat_B[0])

    if col_A != row_B:
        return "Error: Matrices A and B are not multipliable."

    result_mat = [[0 for _ in range(col_B)] for _ in range(row_A)]

    for i in range(row_A):
        for j in range(col_B):
            for k in range(col_A):
                result_mat[i][j] += mat_A[i][k] * mat_B[k][j]

    return result_mat

def main():
    print("Enter the matrix A")
    mat_A = matrix()

    print("\nEnter the matrix B")
    mat_B = matrix()

    result = multiply(mat_A, mat_B)

    if isinstance(result, str):
        print(result)
    else:
        print("\nProduct matrix AB:")
        for row in result:
            print(row)

if __name__ == "__main__":
    main()
