def get_list():

    list_input = []
    elements = int(input("Enter the total number of elements in the list: "))

    for _ in range(elements):
        component = int(input("Enter an integer: "))
        list_input.append(component)

    return list_input

def common_elements(lista,listb):
    seta = set(lista)
    setb = set(listb)
    common_ele = seta.intersection(setb)

    return len(common_ele)

def main():
    print("Enter the list A")
    lista = get_list()

    print("\nEnter the list B")
    listb = get_list()

    common_elements_count = common_elements(lista, listb)
    print(f"\nNumber of common elements between the two lists A and B: {common_elements_count}")


if __name__ == "__main__":
    main()
