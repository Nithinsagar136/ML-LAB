def vowel(input_str):
    vowels = "aeiouAEIOU"
    count_vowels = sum(1 for char in input_str if char in vowels)
    return count_vowels

def consonant(input_str):
    count_consonants = sum(1 for char in input_str if char.isalpha() and char not in "aeiouAEIOU")
    return count_consonants

def main():
    input_str = input("Enter a String of alphabets: ")

    count_vowels = vowel(input_str)
    count_consonants = consonant(input_str)

    print(f"Number of vowels in the string: {count_vowels}")
    print(f"Number of consonants in the string: {count_consonants}")

if __name__ == "__main__":
    main()
